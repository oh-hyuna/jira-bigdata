# 크롤링 작업
# 1. 제목, 조회수, 게시글 URL 수집
# 2. 게시글 내용 수집

# 1. 작업.
url <- "https://www.clien.net/service/group/community?&od=T31&category=0&po=0"
b <- readLines(url, encoding = "UTF-8")   #배열데이터
head(b,20)

library(stringr)
str(b)
#b2 <- b[str_detect(b, "subject_fixed")+1]
#b3 <- gsub("<.*?>|\t", "", b2)
#b4 <- gsub("\t", "", b3) #title
#b4


#title
title <- gsub("\t","", b[which(str_detect(b,"subject_fixed"))+1])
title

# title에 넣어져 있는 url
title_index <- which(str_detect(b, "subject_fixed")) -3 
ul <- b[title_index]
ul2 <- str_extract(ul, ("(?<=href).*(?=data)"))
str_sub(ul2, 3, end=-3)
url_list <- paste0("https://www.clien.net", str_sub(ul2, 3, end=-3))

page_data <- cbind(b4, url_list)
page_data[c(1:4),]
dim(page_data)


#조회수
hit_a <- gsub("<.*?>|\t","", b[which(str_detect(b,"list_hit"))+1])
hit_a

# 페이지별 URL 생성
for(i in 1:10) {
  url <- paste0("https://www.clien.net/service/group/community?&od=T31&category=0&po=", i-1)
  print(url)
}

# 게시글 목록 수집 최종 소스 정리
final <- NULL
library(stringr)
for(i in 1:5) {
  url <- paste0("https://www.clien.net/service/group/community?&od=T31&category=0&po=", i-1)
  b <- readLines(url, encoding = "UTF-8")
  title <- gsub("\t","", b[which(str_detect(b,"subject_fixed"))+1])
  ul <- b[which(str_detect(b, "subject_fixed")) -3]
  ul2 <- str_extract(ul, ("(?<=href).*(?=data)"))
  url_list <- paste0("https://www.clien.net", str_sub(ul2, 3, end=-3))
  page_data <- cbind(title, url_list)
  final <- rbind(final, page_data)
}
dim(final)
write.csv(final, "pagedata.csv", row.names = F)

data <- read.csv("pagedata.csv", encoding = "utf-8")
str(data)
url_list <- as.character(data[,2])
head(url_list)
b <- readLines(url_list[1], encoding = "UTF-8")
head(b,30)
which(str_detect(b, "<body>"))
which(str_detect(b, "</body>"))


which(str_detect(b, "post_content"))
which(str_detect(b, "post_ccls"))

index1 <- which(str_detect(b, "post_content"))
index2 <- which(str_detect(b, "post_ccls"))
b[index1:index2]
q = paste(b[index1:index2], collapse = " ")
#<태그>와 \t(탭) 지우기
str_trim(gsub("<.*?>|\t|&nbsp;","",q))



url_list <- as.character(data[,2])
final_con <- c()
hit_list <- c()
for(i in 1:length(url_list)){
  b <- readLines(url_list[i], encoding = "UTF-8")
  index1 <- which(str_detect(b, "post_content"))
  index2 <- which(str_detect(b, "post_ccls"))
  con3 <- str_trim(gsub("<.*?>|\t|&nbsp;","",paste(b[index1:index2], collapse = " ")))
  hit <- gsub("<.*?>|\t","", b[which(str_detect(b,"list_hit"))+1])
  final_con[i] = con3
  hit_list[i] = hit
  Sys.sleep(1)
}




clien <- cbind(final, final_con, hit_list)
head(clien)
write.csv(clien, "clien.csv", row.names = F)













