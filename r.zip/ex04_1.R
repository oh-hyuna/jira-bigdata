#데이터프레임 합치기

#중간고사 점수
test1 <- data.frame(id = c(1,2,3,4,5),
                    midterm = c(60,80,70,90,85))
#기말고사 점수
test2 <- data.frame(id = c(1,2,3,4,5),
                    final = c(70,83,65,95,80))

test1
test2

#id 기준으로 합치기
total <- left_join(test1,test2, by="id") #기준 컬럼명을 문자열로 표시
total

#담임선생님
name <- data.frame(class = c(1,2,3,4,5),
                   teacher = c("kim","lee","park","choi","jung"))
name
exam

exam_new <- left_join(exam, name, by = "class")
exam_new


# 세로로 합치기
# 학생 1~5번 시험 데이터
group_a <- data.frame(id = c(1,2,3,4,5),
                      test = c(60,80,70,90,85))

# 학생 6~10번 시험 데이터
group_b <- data.frame(id = c(6,7,8,9,10),
                      test = c(70,83,65,95,80))

group_a
group_b

group_all <- bind_rows(group_a,group_b)
group_all


# mpg 데이터에 연료 가격 합치기
mpg <- as.data.frame(ggplot2::mpg)
head(mpg)

fuel <- data.frame(fl = c("c", "d", "e", "p", "r"),
                   price_fl = c(2.35, 2.38, 2.11, 2.76, 2.22),
                   stringsAsFactors = F)
fuel
str(fuel)

mpg_new <- left_join(mpg, fuel, by='fl')
head(mpg_new)

mpg_new %>% select(model, fl, price_fl) %>% head(3)

# 정리
# 1. 조건에 맞는 데이터 로우만 추출
exam %>% filter(english >= 80)
exam %>% filter(english >= 80 & math >= 50)
exam %>% filter(english >= 80 | math >= 50)
exam %>% filter(english %in% c(60,70,80))

# 2. 필요한 컬럼만 추출
exam %>% select(math)

# 3. 함수 조합하기, 일부만 출력
exam %>% select(id,math) %>% head(3)

# 4. 순서대로 정렬
exam %>% arrange(math) #오름차순
exam %>% arrange(desc(math)) #내림차순

# 5. 파생변수 추가하기
exam %>% mutate(total = math + english + science)
exam %>% mutate(test = ifelse(science >= 60, "pass", "fail"))

# 6. 집단별 요약
exam %>% group_by(class) %>% 
         summarise(mean_math = mean(math))

# 7. 데이터 프레임 합치기
# 가로로 합치기
total <- left_join(test1, test2, by ="id")

#세로로 합치기
group_all <- bind_rows(group_a, group_b)

















































