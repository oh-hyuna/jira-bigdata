rm(list=ls())
data_cust = read.csv("./data/data_cust_1_1.csv",header = T)
dim(data_cust)

# 연령대별로 사기자 수가 달라지지 않을까? (AGE)
(count_by_age_gen <- table(subset(data_cust, select = AGE,
                                 subset = (data_cust$SIU_CUST_YN == 1))))

names(count_by_age_gen) <- c("0대", "10대", "20대", "30대", "40대",
                             "50대", "60대", "70대")
barplot(count_by_age_gen, main = "연령대별 사기자 수")


# 성별 별로 사기자 수가 달라지지 않을까? (SEX)
(count_by_sex_gen <- table(subset(data_cust, select = SEX,
                                  subset = (data_cust$SIU_CUST_YN == 1))))
names(count_by_sex_gen) <- c("남", "여")
barplot(count_by_sex_gen, main = "성별별 사기자 수")

pie(count_by_sex_gen,
    cex=0.8,
    main = "성별별 사기자 수",
    labels = paste(names(count_by_sex_gen),"\n",
                   count_by_sex_gen,"명","\n",
                   round(count_by_sex_gen/sum(count_by_sex_gen)*100),"%"))


# 결혼 여부별로 사기자 수가 달라지지 않을까? (WEDD_YN)
(count_by_wed_gen <- table(subset(data_cust, select = WEDD_YN,
                                  subset = (data_cust$SIU_CUST_YN == 1))))
names(count_by_wed_gen) <- c("미혼", "기혼")
barplot(count_by_wed_gen, main = "결혼여부별 사기자 수")

pie(count_by_wed_gen,
    cex = 0.8,
    main = "결혼 여부별 사기자 수",
    labels=paste(names(count_by_wed_gen),"\n",
                 count_by_wed_gen, "명", "\n",
                 round(count_by_wed_gen/sum(count_by_wed_gen)*100),"%"))



data_cust$FP_CAREER

# FP 경력 여부별로 사기자 수가 달라지지 않을까? (FP_CAREER)
(count_by_fp_gen <- table(subset(data_cust, select = FP_CAREER,
                                  subset = (data_cust$SIU_CUST_YN == 1))))
names(count_by_fp_gen) <- c("경력x", "경력o")
barplot(count_by_fp_gen, main = "FP 경력 여부 사기자 수")

data_cust$RESI_TYPE_CODE

# 거주지 별로 사기자 수가 달라지지 않을까? (RESI_TYPE_CODE)
(count_by_resi_gen <- table(subset(data_cust, select = RESI_TYPE_CODE,
                                 subset = (data_cust$SIU_CUST_YN == 1))))
names(count_by_resi_gen) <- c("일반단독주택", "다가구단독주택","영업겸용단독주택",
                              "아파트","연립다가구주택","상가 등 비주거용건물",
                              "오피스텔","숙박업소의 객실 또는 판자집","기숙사","그외")
barplot(count_by_resi_gen, main = "거주지 별 사기자 수")

data_cust$RESI_TYPE_CODE
unique(data_cust$OCCP_GRP_1)

dim(data_cust$SIU_CUST_YN)

# 본인 직업별로 사기자 수가 달라지지 않을까? (OCCP_GRP_1)
(count_by_grp1 <- table(subset(data_cust, select = OCCP_GRP_1,
                                 subset = (data_cust$SIU_CUST_YN == 1))))
names(count_by_grp1) <- c("모름","주부", "자영업","사무직","전문직","서비스","제조업","1차산업","기타")
barplot(count_by_grp1, main = "직업별 사기자 수")

pie(count_by_grp1,
    cex = 0.8,
    main = "직업별 사기자 수",
    labels=paste(names(count_by_grp1),"\n",
                 count_by_grp1, "명", "\n",
                 round(count_by_grp1/sum(count_by_grp1)*100),"%"))



# 배우자 직업별로 사기자 수가 달라지지 않을까? (MATE_OCCP_GRP_1)
(count_by_mategrp1 <- table(subset(data_cust, select = MATE_OCCP_GRP_1,
                               subset = (data_cust$SIU_CUST_YN == 1))))
names(count_by_mategrp1) <- c("모름","주부", "자영업","사무직","전문직","서비스","제조업","1차산업","기타")
barplot(count_by_mategrp1, main = "배우자 직업별 사기자 수")




# 소득이 0인 사람의 데이터를 직업별 평균 (CUST_INCM)
(mean_by_incm_gen <- table(subset(data_cust, select = (CUST_INCM == 0),
                                 subset = (data_cust$SIU_CUST_YN == 1))))
names(count_by_fp_gen) <- c("경력x", "경력o")
barplot(count_by_fp_gen, main = "FP 경력 여부 사기자 수")


