url <- "https://gall.dcinside.com/board/lists/?id=superidea&page=1"
b <- readLines(url, encoding = "UTF-8")
index <- which(str_detect(b, "gall_tit ub-word"))
b2 <- b[index+1]
b2

title <- str_trim(str_extract(b2, ("(?<=</strong>).*(?=</a>)")))
str(title)
con_url <- str_sub(str_extract(b2,("(?<=href).*(?=view)")), 3, end=-3)
con_url2 <- paste0("https://gall.dcinside.com", con_url)

data <- cbind(title, con_url2)

#최종 버전 소스 작성 원하는 페이지 까지 글 제목, 글 URL, 글쓴이 또는 조회수
start_page <- 1
end_page <- 2
dc_list_data <- NULL
for(i in start_page:end_page){
  url <- paste0("https://gall.dcinside.com/board/lists/?id=superidea&page=", i)
  b <- readLines(url, encoding = "UTF-8")
  index <- which(str_detect(b, "gall_tit ub-word"))
  b2 <- b[index+1]
  title <- str_trim(str_extract(b2, ("(?<=</strong>).*(?=</a>)")))
  title <- title[2:51]
  con_url <- str_sub(str_extract(b2,("(?<=href).*(?=view)")), 3, end=-3)
  con_url2 <- paste0("https://gall.dcinside.com", con_url)
  con_url2 <- con_url2[2:51]
  nick_name <- str_extract(b[which(str_detect(b, "nickname"))], ("(?<=<em>).*(?=</em>)"))
  count <- gsub("<.*?>|\t", "", b[which(str_detect(b, "gall_count"))])
  count <- count[2:51]
  recommend <- gsub("<.*?>|\t", "", b[which(str_detect(b, "gall_recommend"))])
  recommend <- recommend[2:51]
  data <- cbind(title, con_url2, nick_name, count, recommend)
  dc_list_data <- rbind(dc_list_data, data)
}
head(dc_list_data)
write.csv(dc_list_data, "dc_list_data.csv", row.names = F)





