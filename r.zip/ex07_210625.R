# Lab 1. 보험 고객 데이터, 청구 사기 데이터 (사기자 예측)

# 메모리에서 전체 변수 제거
rm(list=ls())   #변수 지우기

# 작업 디렉토리 확인 및 설정
getwd()  #home directory 확인
setwd("C:/Users/admin/Documents/R/r-base") #working directory 바꾸기

# 원본 데이터 읽기
data_cust <- read.csv('./data/BGCON_CUST_DATA.csv', 
                        header=T, sep=",",
                        encoding = "CP949",
                        fileEncoding = "UCS-2")  # excel파일 encoding지정
data_claim <- read.csv('./data/BGCON_CLAIM_DATA.csv', 
                      header=T, sep=",",
                      encoding = "CP949",
                      fileEncoding = "UCS-2")
data_cntt <- read.csv('./data/BGCON_CNTT_DATA.csv', 
                       header=T, sep=",",
                       encoding = "CP949",
                       fileEncoding = "UCS-2")

data_fmly <- read.csv('./data/BGCON_FMLY_DATA.csv', 
                       header=T, sep=",",
                       encoding = "CP949",
                       fileEncoding = "UCS-2")

data_fpinfo <- read.csv('./data/BGCON_FPINFO_DATA.csv', 
                       header=T, sep=",",
                       encoding = "CP949",
                       fileEncoding = "UCS-2")

dim(data_cust)
dim(data_claim)
dim(data_cntt)
dim(data_fmly)
dim(data_fpinfo)
str(data_cust)

# 정상, 사기자 수 확인
count_siu <- table(data_cust$SIU_CUST_YN)
(count_siu <- table(data_cust$SIU_CUST_YN)) #괄호에 넣어서 변수 확인
# 사기자 수 : 1806, 정상 수 : 18808
names(count_siu) <- c("분석대상", "정상인", "사기자")
pie(count_siu, 
    cex=0.8, #빨간색
    main = "사기자 수",
    labels = paste(names(count_siu), "\n",
                   count_siu, "명", "\n",
                   round(count_siu/sum(count_siu)*100),"%"))

# 결측치 확인 ____ NA, "", NULL, 999, 9999
# 나이 데이터를 세대별로 카테고리화 작업
# Y/N -> 0/1

# 나이를 세대별로
# R function -- 이름을 따로 설정하지 않음 = 익명함수
# function(parameter)
age_to_gen <- function(row) {
  row = floor(row / 10)
}

# pandas의 apply  --> R 의 lapply / sapply
data_cust$AGE <- sapply(data_cust$AGE, age_to_gen)
data_cust$AGE[1]

# Y = 1, N = 0 으로 변환
yn_to_10 <- function(row) {
  if(row == "Y")
    row = 1
  else if(row == "N")
    row = 0
  else
    row = ""
}

data_cust$SIU_CUST_YN <- sapply(data_cust$SIU_CUST_YN, yn_to_10)
#data_cust$WEDD_YN <- sapply(data_cust$WEDD_YN, yn_to_10)
data_cust$FP_CAREER <- sapply(data_cust$FP_CAREER, yn_to_10)


# NA를 0으로 처리
na_to_0 <- function(row) {
  if(is.na(row))
    row = 0
  else
    row = row
}
data_cust$RESI_TYPE_CODE <- sapply(data_cust$RESI_TYPE_CODE, na_to_0)
data_cust$TOTALPREM <- sapply(data_cust$TOTALPREM, na_to_0)

sum(is.na(data_cust))

# 지역 코드 정리
ctpr_to_code <- function(row) {
  if(row=="서울") 
    row = 1
  else if(row=="부산")
    row = 2
  else if(row=="대구")
    row = 3
  else if(row=="인천")
    row = 4
  else if(row=="광주")
    row = 5
  else if(row=="대전")
    row = 6
  else if(row=="울산")
    row = 7
  else if(row=="세종")
    row = 8
  else if(row=="경기")
    row = 9
  else if(row=="강원")
    row = 10
  else if(row=="충북")
    row = 11
  else if(row=="충남")
    row = 12
  else if(row=="전북")
    row = 13
  else if(row=="전남")
    row = 14
  else if(row=="경북")
    row = 15
  else if(row=="경남")
    row = 16
  else if(row=="제주")
    row = 17
  else
    row = 0
}

data_cust$CTPR <- sapply(data_cust$CTPR, ctpr_to_code)
# 변환작업을 했을때 각각이 리스트로 나오는 경우에 unlist() 사용
# 현재는 사용 안해도 됨
# unlist(data_cust$CTPR[1:4])


# MINCRDT, MAXCRDT NA 데이터를 6으로 변환
na_to_6 <- function(row) {
  if(is.na(row))
    row = 6
  else
    row = row
}
data_cust$MINCRDT <- sapply(data_cust$MINCRDT, na_to_6)
data_cust$MAXCRDT <- sapply(data_cust$MAXCRDT, na_to_6)
data_cust$CUST_INCM <- sapply(data_cust$CUST_INCM, na_to_0)
data_cust$JPBASE_HSHD_INCM <- sapply(data_cust$JPBASE_HSHD_INCM, na_to_0)

str(data_cust)
sum(is.na(data_cust))

# OCCP_GRP 첫글자 빼내서 코드화
occp_grp_1_to_no <- function(row) {
  row = substr(row,1,1)
  if(row =="")
    return(0)
  else
    return(as.integer(row))
}

data_cust$OCCP_GRP_1 <- sapply(data_cust$OCCP_GRP_1, occp_grp_1_to_no)


#결혼 유무 널 문자를 N으로 
table(data_cust$WEDD_YN)
nullstring_to_n <- function(row) {
  if(row == "N")
    row = "N"
  else if(row == "Y")
    row = "Y"
  else
    row = "N"
}

data_cust$WEDD_YN <- sapply(data_cust$WEDD_YN, nullstring_to_n)
data_cust$WEDD_YN <- sapply(data_cust$WEDD_YN, yn_to_10)

write.csv(data_cust, "./data/data_cust_1_1.csv", row.names = F)
str(data_cust)


unique(data_cust$MATE_OCCP_GRP_1)
data_cust$MATE_OCCP_GRP_1 <- sapply(data_cust$MATE_OCCP_GRP_1, occp_grp_1_to_no)
write.csv(data_cust, "./data/data_cust_1_1.csv", row.names = F)





































