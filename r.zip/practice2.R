# 1. mpg데이터의 class suv, compact 등 자동차를 측징에 따라 일곱종류로 분류한 변수
  # 어떤 차종의 도시연비가 높은지 비교해 보려고 합니다. class 별 cty 평균
mpg <- as.data.frame(ggplot2::mpg)

mpg %>% group_by(class) %>% 
        summarise(mean_cty = mean(cty))

# 2. 1번에서 cty 평균이 높은 순으로 정렬
mpg %>% group_by(class) %>% 
        summarise(mean_cty = mean(cty)) %>% 
        arrange(desc(mean_cty))

# 3. 어떤 회사 자동차의 hwy가 가장 높은지 알아보려고 한다. hwy평균이 가장 높은
#    회사 세 곳 출력
mpg %>% group_by(manufacturer) %>% 
        summarise(mean_hwy = mean(hwy)) %>% 
        arrange(desc(mean_hwy)) %>% 
        select(manufacturer) %>% 
        head(3)

# 4. 각 회사별 compact 차종 수를 내림차순으로 정렬
mpg %>% filter(class == "compact") %>% 
        group_by(manufacturer) %>% 
        summarise(compact_n = n()) %>% 
        arrange(desc(compact_n))


