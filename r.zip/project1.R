  ## 서울시 생활인구 변화 분석

  ## 데이터 출처 : "행정동별 서울생활인구(내국인)" -> 집계 및 변환
  ##               서울열린데이터광장(http://data.seoul.go.kr/dataList/OA-14991/S/1/datasetView.do)

  ## 데이터 설명 : 2019, 2020년 12월 한달 간 서울시 25개 자치구, 24개 시간대, 7개 연령대별 생활인구수

  ## 분석 목표   : 2019년 대비 2020년의 생활인구 변화의 특성 파악
 
  # "##!" : <= 요표시가 실습 부분
  





# 0. 준비 -------------------------------------------------------------------

  ## 패키지 불러오기 
  library(dplyr)
  library(ggplot2)


  rm(list = ls())

  ## 데이터 불러오기
  data_2019 = read.csv('./R/r-base/data/SEOUL_PEOPLE_GU_2019.csv', fileEncoding='UTF-8', colClasses=c(`시간대`='character'))
  data_2020 = read.csv('./R/r-base/data/SEOUL_PEOPLE_GU_2020.csv', fileEncoding='UTF-8', colClasses=c(`시간대`='character'))

  data_2019 %>% head()
  data_2020 %>% head()

  
  
  
  
  
  
# 1. 전처리 ------------------------------------------------------------------

  
  ##! 데이터 결합하기
  
  SP_GU <- rbind(data_2019,data_2020)  
  
  
  SP_GU %>% head(10)
  SP_GU %>% tail(10)
  
  
  head(SP_GU$기준일)

  
  ##! `기준일`을 as.Date( )로 Date 형식으로 변환
  
  SP_GU$기준일 <- as.Date(SP_GU$기준일)
  str(SP_GU)
  #SP_GU <- SP_GU %>% mutate(기준일 = as.Date(기준일))
  
  
  ## `연도` 변수 생성
  SP_GU = SP_GU %>% 
    mutate( 연도 = format(기준일, '%Y') )
    ### %Y : 4자리수 연도
    
    ### 날짜/시간 패턴 참고
    ?strptime
  
    ### %u : 요일(1~7, 1은 월요일)
    ### %a : 요일(월화수목금토일)
  
    
  tail(SP_GU)
  
  ##! weekdays( ) 혹은 format( )으로 `요일` 변수 생성
  SP_GU = SP_GU %>% 
    mutate( 요일 = format(기준일, '%u_%a'))
  
  

# 2. 요약 및 시각화 ----------------------------------------------------------------

  ##! '2019-12-24', '2020-12-24' 만 선택 후 생활인구수 합계 비교
  ### 조건 : 기준일 %in% c(as.Date('2019-12-24'), as.Date('2020-12-24'))
  names(SP_GU)
  SP_GU %>% 
    filter(기준일 %in% c(as.Date('2019-12-24'), as.Date('2020-12-24'))) %>% 
    group_by(기준일) %>% 
    summarise(생활인구수_합계 = sum(생활인구수))
  


  
  ##! '2019-12-24', '2020-12-24'만 선택 후 18시~ 21시 생활인구수 합계 비교
    ### 조건 : 시간대 %in% c('18','19','20','21')
  SP_GU %>% filter(기준일 %in% c(as.Date('2019-12-24'), as.Date('2020-12-24'))) %>%
    filter(시간대 %in% c('18','19','20','21')) %>% 
    group_by(기준일) %>% 
    summarise(생활인구수_합계 = sum(생활인구수))  
  
  
  
  ##! 자치구별 생활인구수 합계 계산 / 막대그래프 시각화
  
    agg1 <- SP_GU %>% group_by(자치구) %>% 
      summarise(total = sum(생활인구수))
    agg1 %>% ggplot(aes(자치구, total)) + geom_col()
  
    #### 자치구 순서 정렬 및 90도 회전
    agg1 %>% ggplot(aes(reorder(자치구, -total),total)) + geom_col() +
      theme(axis.text.x = element_text(angle=90))
  

  ##! 연도/자치구별 생활인구수 합계 계산 / 나란히 그린 막대그래프 시각화
    
    agg2 <- SP_GU %>% group_by(연도, 자치구) %>% 
      summarise(total = sum(생활인구수))
    agg2 %>% ggplot(aes(자치구,total,fill=연도)) + geom_col(position = 'dodge') 
    #position 옵션을 넣으면 쌓아지지 않고 옆으로 됨

  
  
  
  ##! 2020년의 각 자치구별 생활인구의 연령대 비중 계산 / 비중을 쌓아올린 막대그래프로 시각화
    ### 각 구별 막대그래프의 높이는 비중의 합계인 1로 동일

    agg3 <- SP_GU %>% filter(연도 == "2020") %>% 
              group_by(자치구, 연령대) %>% 
              summarise(total = sum(생활인구수)) %>% 
              mutate(prop = total / sum(total))
    agg3 %>% ggplot(aes(자치구, total, fill=연령대)) + geom_col(position = 'fill')
  
    # 열지도(heatmap) 시각화 
    agg3 %>% ggplot(aes(연령대, 자치구, fill = prop)) +
      geom_tile() +
      scale_fill_distiller(palette = "Blues", direction = 1)
  
    
    
  ##! 연도/자치구/요일별 일평균 생활인구수 계산
    ### 주의 : 하루에 24개 시간대와 7개 연령대의 관측치가 있음
    ### 다음 예제 실행을 위해 요약 결과는 agg5로, 일평균 생활인구수는 MEAN으로 저장
  names(SP_GU)
  agg4 <- SP_GU %>% group_by(연도, 자치구, 요일, 기준일) %>% 
    summarise(total = sum(생활인구수))
  
  agg5 <- agg4 %>% summarise(mean = mean(total))
  
  
  ##! 연도/자치구/요일별 일평균 생활인구수의 열지도 시각화
    ### 요일(x)/자치구(y)별 일평균 생활인구수 열지도를
    ### facet_wrap( )을 활용하여 연도별로 분할 작성
    
   agg5 %>% ggplot(aes(요일, 자치구, fill=mean)) + geom_tile() +
     facet_wrap(vars(연도)) + 
     scale_fill_distiller(palette = "YlGnBu", direction = 1)

  
    
  #----------------------------------^06.28-------------------#
  
  
  ## tidyr의 spread( )를 활용한 형태 변환 및 변화율 계산
  library(tidyr)
  agg5
  agg5 %>% 
    spread(연도, mean)
    ### spread(열 변수들로 변환할 그룹변수, 표를 채울 집계 변수)
  
  agg6 = agg5 %>% 
    spread(연도, mean) %>% 
    mutate( RATIO = `2020`/`2019`)
  agg6
    ### 2019년 대비 2020년 변화율 계산
  
  agg6 %>% 
    ggplot(aes(요일, 자치구, fill=RATIO)) +
    geom_tile() + 
    scale_fill_distiller(palette = 'Reds')
    
  
  ##! 연도/연령대/요일별 일평균 생활인구수를 계산하고
  ##! 2019년 대비 2020년의 변화율을 열지도로 시각화
  
  agg7 <- SP_GU %>% group_by(연도, 연령대, 요일, 기준일) %>% 
    summarise(total = sum(생활인구수))
  
  agg8 <- agg7 %>% summarise(mean = mean(total))
  agg9 <- agg8 %>% spread(연도, mean) %>% 
    mutate(ratio = `2020` / `2019`)
  
  agg9 %>% ggplot(aes(요일, 연령대, fill=ratio)) + geom_tile() +
    scale_fill_distiller(palette = 'Reds')
  
  
    ##! 위의 분석을 18시 ~ 22시 4시간만 선택해서 반복
    ### 조건 : 시간대 %in% c('18','19','20','21')
  
  agg10 <- SP_GU %>% filter(시간대 %in% c('18','19','20','21')) %>% 
    group_by(연도, 연령대, 요일, 기준일) %>% 
    summarise(total = sum(생활인구수)) %>% 
    summarise(mean = mean(total)) %>% 
    spread(연도, mean) %>% 
    mutate(ratio = `2020`/`2019`)
    
    
  agg10 %>% ggplot(aes(요일, 연령대, fill=ratio)) + geom_tile() +
    scale_fill_distiller(palette = "YlGnBu")
  
  

  
# End of script     
  