# midwest 문제
# 1. popadults는 해당 지역의 성인 인구,
#    poptotal은 전체인구를 나타냄
#    midwest 데이터에 전체인구 대비 미성년 인구 백분율 변수 추가

midwest <- as.data.frame(ggplot2::midwest)
head(midwest, 5)

midwest <- midwest %>% mutate(ratio = (poptotal - popadults) / poptotal *100 )
head(midwest,5)

# 2. 미성년 인구 백분율이 가장 높은 상위 5개 county의 미성년 인구 백분율
midwest %>% arrange(desc(ratio)) %>% select(county,ratio) %>% head(5)

str(midwest)

# 3. 분류표의 기준에 따라 미성년 비율 등급 변수를 추가, 각 등급에 몇 개의 지역이 있는지
# 분류 - large 40% 이상  /  middle 30~40% 미만  / small  30% 미만
midwest %>% mutate(grade = ifelse(ratio >= 40, "large", ifelse(ratio >= 30, "middle", "small"))) %>% 
                      group_by(grade) %>% 
                      summarise(count = n())

# 4. popasian은 해당 지역의 아시아인 인구
# 전체 인구 대비 아시아인 인구 백분율 변수 추가
# 하위 10개 지역의 state, county, 아시아인 인구 백분율 출력

midwest %>% mutate(asian_ratio = popasian / poptotal * 100) %>% 
            arrange(asian_ratio) %>% 
            select(state, county, asian_ratio) %>% 
            head(10)


