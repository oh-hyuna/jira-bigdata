#변수 선언
a = 1
b <- 3
4 -> c
# 이 데이터의 값은 나이 데이터 입니다.
age = 10 #변수명 중요!!
# 연산자
a + b
a - b
a * b
a / b
a % b

#여러 데이터로 구성된 변수
var <-c(1,2,3,4,5)
var
var1 <- c(1:5) #연속된 값을 선언 하고자 할 땐 :를 이용한다
var1

var2 <- seq(1,5) #파이썬의 range() 함수와 같음 
var2

var3 <- seq(1,10,by=2)#2간격으로 연속값생성성
var3

var + 2

var + var2

str <- "a"
str

str2 <-"text"
str2

str3 <- c("a","b","c")
str3

str4 <- c("Hello","World","is","Good")
str4

#함수 적용
x <- c(1,2,3)
mean(x)
max(x)
min(x)

str4
paste(str4,collapse = ",")
paste(str4,collapse = " ")

x_mean <- mean(x)
x_mean

str5_paste <-paste(str4, collapse = " ")
str5_paste

#패키지 설치
#패키지 로드
#함수 사용
#ggplot2 package 사용 예
install.packages("ggplot2") #패키지 설치
library(ggplot2) #패키지 로드

x <- c('a','b','c','d','a','d')
x
qplot(x) #빈도수를 막대그래프로 그려줌(빈도 막대그래프 출력)
?qplot


#Q1. 다섯 명의 항생이 시험을 봤음. 시험 점수를 담은 변수 선언
# 80, 60, 70, 50, 90
score <- c(80,60,70,50,90)

#Q2. 전체 평균을 구하여 출력하시오.
mean(score)

#Q3. 전체 평균을 담을 변수를 선언하고 변수를 출력하세요.
score_mean <- mean(score)
score_mean


