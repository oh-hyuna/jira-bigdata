# 기술통계 관련 함수
exam <- read.csv("./data/csv_exam.csv")
exam

head(exam)  #앞에서부터 6행 출력
head(exam, 3)  #앞에서부터 3행 출력
tail(exam)  #뒤에서부터 6행 출력
tail(exam, 3) #뒤에서부터 3행 출력
View(exam) #뷰어 창에서 데이터 확인 -- 사용하지 않는 게 좋음
dim(exam)  #데이터 차원 출력 - 몇행 / 몇열
str(exam)  #데이터 속성 출력 / pandas의 info()
summary(exam) #데이터 전체  요약 / pandas의 describe()


#mpg 데이터를 이용한 기술 통계 함수 사용
mpg <- as.data.frame(ggplot2::mpg)
head(mpg)
dim(mpg)
tail(mpg)
summary(mpg)
str(mpg)

?mpg

install.packages("dplyr")
library(dplyr)  #python에서의 pandas와 비슷한 역할

df_raw <- data.frame(var1 = c(1,2,1), var2 = c(2,3,2))
df_raw

df_new <- df_raw   #원본데이터 유지를 위해 복사
df_new

df_new <- rename(df_new, v2 = var2)  
#(바꾸고 싶은 이름=바꿀 이름), var2를 v2로 바꿈
df_new 

df_raw
df_new

#value copy를 하면 메모리 사용량이 늘어남

#Q1. mpg데이터를 불러와서 복사
#Q2. 복사한 데이터 프레임의 cty 컬럼을 city,
      # hwy 컬럼을 highway로 변경, 일부데이터 출력

mpg <- as.data.frame(ggplot2::mpg)
head(mpg,3)
mpg_new <- mpg  #mpg data copy
head(mpg_new)

#컬럼명 변경
mpg_new <- rename(mpg_new, city=cty) 
mpg_new <- rename(mpg_new, highway = hwy)
head(mpg_new)

#파생변수 - 기존에 있던 변수를 변형해서 추가하는 변수
df <- data.frame(var1=c(4,3,8), var2=c(2,6,1))
df

df$var_sum <- df$var1 + df$var2
df

df$var_mean <- (df$var1 + df$var2) / 2
df

#통합 연비 변수 total
mpg$total <- (mpg$cty + mpg$hwy) / 2
head(mpg,5)

summary(mpg$total)

#통합 연비 분포 보기
hist(mpg$total)

#조건문 사용
ifelse(mpg$total >=20, "pass","fail")
mpg$test <- ifelse(mpg$total >= 20, "pass", "fail")
tail(mpg,10)

#빈도를 확인할 수 있는 table()
table(mpg$test)
library(ggplot2)
qplot(mpg$test)


# A등급:30이상, B등급:20~29, C등급:20미만
mpg$grade <- ifelse(mpg$total >= 30,"A",
                    ifelse(mpg$total >= 20,"B","C"))
head(mpg,3)
table(mpg$grade)
qplot(mpg$grade)


mpg$grade2 <- ifelse(mpg$total >= 30, "A",
                     ifelse(mpg$total >= 25, "B",
                            ifelse(mpg$total >= 20, "C", "D")))
head(mpg,5)


#정리
#1. 데이터 준비, 패키지 준비
mpg <- as.data.frame(ggplot2::mpg) #데이터 불러오기
library(dplyr) #dplyr로드
library(ggplot2) #ggplot2로드

#2. 데이터 파악 (탐색)
head(mpg) #Raw 데이터 앞 부분
tail(mpg) #Raw 데이터 뒷 부분
View(mpg) #뷰창에서 Raw데이터 확인
dim(mpg)  #데이터 차원 확인
str(mpg)  #속성 확인
summary(mpg) #요약(기술) 통계량

#3. 컬럼명 지정
mpg <- rename(mpg$cty, city = cty)

#4. 파생변수 생성
mpg$total <- (mpg$cty + mpg$hwy) / 2
#조건문 사용
mpg$test <- ifelse(mpg$total >= 20,"pass","fail")

#5. 빈도 확인
table(mpg$test)
qplot(mpg$test)




































