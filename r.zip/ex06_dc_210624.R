library(stringr)
url <- "https://gall.dcinside.com/board/lists/?id=superidea&page=1"
b <- readLines(url, encoding = "UTF-8")

index <- which(str_detect(b,"gall_tit ub-word"))
b2 <- b[index + 1]
b2

#정규표현식 -- "(?<= 검색하고 싶은 문자열 시작).*(?<= 끝 )"
title <- str_trim(str_extract(b2, ("(?<=</strong>).*(?=</a>)")))
title

con_url <- str_sub(str_extract(b2,("(?<=href).*(?=view)")),3,end=-3)
con_url
con_url2 <- paste0("https://gall.dcinside.com", con_url)

data <- cbind(title, con_url2)

#-------#
writer_index <- which(str_detect(b,"nickname"))
writer <- b[writer_index]
writer2 <-  str_extract(writer,("(?<=em).*(?=/em>)"))
dim(writer2)

#최종 버전 소스 작성 원하는 페이지까지 글 제목, 글 URL, 글쓴이 또는 조회수
#rbind -- 데이터를 아래로 붙임
#cbind -- 데이터를 옆으로 붙임

dc_data = NULL
for (i in 1:5) {
  url <- paste0("https://gall.dcinside.com/board/lists/?id=superidea&page=",i)
  b <- readLines(url, encoding = "UTF-8")
  index <- which(str_detect(b,"gall_tit ub-word"))
  b2 <- b[index + 1]
  title <- str_trim(str_extract(b2, ("(?<=</strong>).*(?=</a>)")))
  con_url <- str_sub(str_extract(b2,("(?<=href).*(?=view)")),3,end=-3)
  con_url2 <- paste0("https://gall.dcinside.com", con_url)
  writer_index <- which(str_detect(b,"nickname"))
  writer <- b[writer_index]
  writer2 <-  str_extract(writer,("(?<=em>).*(?=</em>)"))
  data <- cbind(title[-1], con_url2[-1], writer2)
  dc_data <- rbind(dc_data,data)
  Sys.sleep(1)
}

head(dc_data,20)
write.csv(dc_data,"dc_data.csv", row.names = F)








