# 농산물 가격 변동 분석
rm(list = ls())

# plyr : 데이터 핸들링을 하기 위한 라이브러리
# ggplot2 : 시각화
# stringr : 문자열 데이터 핸들링을 하기 위한 라이브러리
# zoo : 문자 타입의 데이터를 date 타입으로 변환
# corrplot : 상관분석을 위한 라이브러리
# RColorBrewer : 색상 처리 라이브러리
library1 <- c("plyr", "ggplot2", "stringr", "zoo",
              "corrplot", "RColorBrewer")
unlist(lapply(library1, require, character.only = T))

# 지역별 돼지고기 가격 연관성 분석
# 한국농수산식품유통공사 : 2011년 ~ 2013년 데이터
product <- read.csv("./R/r-base/data/product.csv", header = T, 
                    fileEncoding = "UTF-8")
code <- read.csv("./R/r-base/data/code.csv", header = T,
                 fileEncoding = "EUC-KR")

head(product, 10)
head(code, 10)

dim(product)
dim(code)
tail(product, 10)

# 부류코드 : 농축산물의 범주에 따라 분류한 코드. 
# 100(식량작물), 200(채소류)
# 품목코드 : 품목에 따른 분류
# 지역코드 : 지역에 따른 분류
# 마트코드 : 마트에 따른 분류


names(product) <- c("data", "category", "item",
                    "region", "mart", "price")
head(product, 2)
category <- subset(code, code$구분코드설명 == "품목코드")
category
names(category) <- c("code", "exp", "item", "name")
head(category, 2)


total.pig <- product[which(product$item == 514),]  # boolean index
head(total.pig, 3)
region <- subset(code, code$구분코드설명 == "지역코드")
head(region,2)

names(region) <- c("code", "exp", "region", "name")
head(category, 2)

day.pig <- merge(total.pig, region, by = "region", all = T)
head(day.pig, 2)

# 일별로 정렬한 후, 지역별로 돼지고기 평균가격을 구함.
# dlply() : 데이터프레임을 품목별로 list 형태로 출력
# ddply() : 데이터프레임을 분리하여 함수를 적용시킨 후 데이터프레임 형태로 출력 
total.pig.mean <- dlply(
  ddply(
    ddply(
      day.pig, .(data), summarise, name = name, region = region, price = price
    ), .(data, name), summarise, mean.price = mean(price)
  ), .(name)
)

head(total.pig.mean)
typeof(total.pig.mean)

for (i in 1:length(total.pig.mean)) {
  cat(
    names(total.pig.mean)[i], "의 데이터 길이는 " , nrow(total.pig.mean[[i]]),
    " 이다 \n"
  )
}


day.pig <- day.pig[!day.pig$name %in% c("순천", "안동", "용인","의정부",
                                        "포항", "춘천", "창원"),]
tail(day.pig)

# 지역, 일자별 돼지고기 평균가격
pig.region.daily.mean <- ddply(day.pig, .(name, region, data),
                               summarise, mean.price = mean(price))
head(pig.region.daily.mean)


# 지역, 월별 돼지고기 평균가격

pig.region.monthly.mean <- ddply(pig.region.daily.mean, 
           .(name, region, month = str_sub(pig.region.daily.mean$data,1,7)),
           summarise, mean.price = mean(mean.price))
head(pig.region.monthly.mean)



# 시각화
# 월별 돼지고기 가격 시각화
str(pig.region.monthly.mean)
pig.region.monthly.mean$month <- as.Date(
  as.yearmon(pig.region.monthly.mean$month, "%Y-%m"))
str(pig.region.monthly.mean)

ggplot(pig.region.monthly.mean, aes(x=month, y=mean.price,
                                    color=name, group=name)) +
  geom_line() +
  theme_bw() +
  geom_point(size = 6, shape = 20, alpha = 0.5) +  #꺾이는 부분 마킹
  ylab("돼지고기 가격") +
  xlab("")


# geom_line() : line 형태로 시각화
# geom_point() : point 형태의 시각 효과
# theme_bw() : 흰색 배경에 검은색 눈금선 테마
# xlab(), ylab() : x축, y축 이름 지정정


# 지역별 연간 돼지고기 평균가격 시각화
pig.region.yearly.mean <- ddply(pig.region.monthly.mean,
                .(name, region, 
                  year = str_sub(pig.region.monthly.mean$month,1,4)),
                  summarise, mean.price = mean(mean.price))
head(pig.region.yearly.mean, 2)


ggplot(pig.region.yearly.mean, aes(x=year, y=mean.price,
                                    color=name, group=name)) +
  geom_line() +
  theme_bw() +
  geom_point(size = 6, shape = 20, alpha = 0.5) +  #꺾이는 부분 마킹
  ylab("돼지고기 가격") +
  xlab("")

ggplot(pig.region.yearly.mean, aes(x=name, y=mean.price, fill=factor(year))) +
  theme_bw() + geom_bar(stat = "identity", position = "dodge", color = "white") +
  ylab("돼지고기 가격") +
  xlab("")


ggplot(pig.region.monthly.mean, aes(x=name, y=mean.price,
                                    fill=name)) +
  theme_dark() + geom_boxplot() +
  xlab("") +
  ylab("돼지고기 가격")


# 도시들 간의 상관관계를 분석
temp <- dlply(pig.region.daily.mean, 
              .(name), summarise, mean.price)
pig.region <- data.frame(서울 = unlist(temp$서울),
                         부산 = unlist(temp$부산),
                         대구 = unlist(temp$대구),
                         인천 = unlist(temp$인천),
                         광주 = unlist(temp$광주),
                         대전 = unlist(temp$대전),
                         울산 = unlist(temp$울산),
                         수원 = unlist(temp$수원),
                         청주 = unlist(temp$청주),
                         전주 = unlist(temp$전주),
                         제주 = unlist(temp$제주))

cor_pig <- cor(pig.region)
corrplot(cor_pig, method = "color", type = "upper",
         order = "hclust", addCoef.col = "white", 
         tl.srt = 0, tl.col = "black", tl.cex = 0.7, 
         col = brewer.pal(n = 8, name = "PuOr"))
str(pig.region.monthly.mean)
ggplot(pig.region.monthly.mean[
  pig.region.monthly.mean$region %in% c(2401, 2200, 1101),
] #ggplot의 첫번째 파라미터
,aes(x=month, y=mean.price, colour = name, group = name)) +
  geom_line() +
  theme_classic() +
  geom_point(size = 6, shape = 20, alpha=0.5) +
  ylab("돼지고기 가격") +
  xlab("")


























































































