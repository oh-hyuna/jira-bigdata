#데이터프레임
english <- c(90,80,60,70)
english

math <- c(50,60,100,20)
math

#데이터프레임 생성
df_midterm <- data.frame(english, math)
df_midterm

class <- c(1,1,2,2)
class

df_midterm <- data.frame(english, math,class)
df_midterm

#영어 점수에 대한 평균
mean(df_midterm$english) #특정 컬럼 접근시 $ 기호를 사용용
mean(df_midterm$math)

df_midterm <- data.frame(english = c(90,80),
                         math = c(50,60),
                         class = c(1,2))
df_midterm


#Q1. data.frame()과 c()를 조합해서 데이터 프레임 만들기
df_fruit <- data.frame(제품 = c("사과","딸기","수박"),
                       가격 = c(1800,1500,3000),
                       판매량 = c(24,38,13))

df_fruit
#Q2. 앞에서 만든 데이터 프레임에서 과일 가격 평균, 판매량 평균 구하시오 
mean(df_fruit$가격)
mean(df_fruit$판매량)


# 외부데이터 이용
install.packages("readxl")
library(readxl)

df_exam <- read_excel("./data/excel_exam.xlsx") 
#경로설정 중요 : 
#현재는 r-base가 기준 (.은 현재디렉토리) (/하위디렉토리)  <- 상대경로 설정
df_exam
mean(df_exam$english)
mean(df_exam$science)

#절대경로 설정
df_exam <- read_excel("C:\\Users\\admin\\Documents\\R\\r-base\\data\\excel_exam.xlsx")
#※ 리눅스 환경 --  "C:/Users/admin/"

#엑셀 파일 첫번째 행이 컬럼명이 아닐 경우
df_exam_novar <- read_excel("./data/excel_exam_novar.xlsx", col_names=FALSE)
df_exam_novar

#엑셀 파일에 시트가 여러개 있을 때
df_exam_sheet <- read_excel("./data/excel_exam_sheet.xlsx",sheet=3)
df_exam_sheet

#csv 파일 
df_csv_exam <-read.csv("./data/csv_exam.csv")
df_csv_exam
?read.csv

#문자가 들어있는 파일을 불러올때는 stringAsFactors = F
df_csv_exam <-read.csv("./data/csv_exam.csv",stringsAsFactors = F)
df_csv_exam

df_midterm

# csv파일로 저장
write.csv(df_midterm, file="./data/df_midterm.csv")


#RData 파일 활용  R에서만 이용 / 변수 자체를 저장하고 그대로 꺼내줌
save(df_midterm, file="./data/df_midterm.rda")
rm(df_midterm)
df_midterm
load("./data/df_midterm.rda")
df_midterm





