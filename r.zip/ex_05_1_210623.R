library(ggplot2)

#data에 그래프를 그릴 데이터 지정
#aes에 x축과 y축에 사용할 변수 지정
#+ geom_point()를 이용해 산점도 그래프 추가

# 1. 배경설정
ggplot(data=mpg, aes(x=displ, y=hwy))
# 2. 그래프 설정
ggplot(data=mpg, aes(x=displ, y=hwy)) + geom_point()
# x limit(범위) 설정 -> xlim /y limit(범위) 설정 -> ylim
ggplot(data=mpg, aes(x=displ, y=hwy)) + 
    geom_point() + 
    xlim(3,6) + 
    ylim(10,30)


#qplot()  --> python의 matplotlib #전처리시 신속히 시각화
#ggplot() --> python의 seaborn #최종보고용, 분석결과(예쁘게)

#x축 cty, y축 hwy 산점도 그려보자
ggplot(data=mpg, aes(x=cty, y=hwy)) +
  geom_point()

#midwest
midwest <- as.data.frame(ggplot2::midwest)
ggplot(data=midwest, aes(x = poptotal, y = popasian)) +
  geom_point() +
  xlim(0, 500000) +
  ylim(0,10000)

#집단간 평균 막대 그래프
mpg <- as.data.frame(ggplot2::mpg)
df_mpg <- mpg %>% 
  group_by(drv) %>% 
  summarise(mean_hwy = mean(hwy))
df_mpg

ggplot(data = df_mpg, aes(x=drv, y=mean_hwy)) +
  geom_col()

?reorder

#reorder()에 x축 변수와 정렬기준으로 삼을 변수를 지정
# - 를 앞에 붙이면 내림차순
ggplot(data = df_mpg, aes(x=reorder(drv,-mean_hwy), y=mean_hwy)) +
  geom_col()

# 히스토그램 그래프(빈도그래프)
# y축 값을 따로 지정하지 않음
ggplot(data=mpg, aes(x=drv)) + geom_bar()
ggplot(data=mpg, aes(x=hwy)) + geom_bar()

# 평균 막대 그래프 - geom_col()
# -> 데이터를 요약한 평균표를 먼저 만들고 그래프 생성
# 빈도 막대 그래프
# -> 별도로 표를 만들지 않고 그래프 생성 geom_bar()


# Q1. suv 차종의 어떤 회사가 도시 연비가 높은지 알아보자. 상위 5개 정리
mpg %>% filter(class == "suv") %>% 
        group_by(manufacturer) %>% 
        summarise(mean_cty = mean(cty)) %>% 
        arrange(desc(mean_cty)) %>% 
        head(5) -> df
df

ggplot(data=df, aes(x=reorder(manufacturer, -mean_cty), y = mean_cty)) + 
  geom_col()


# Q2. 자동차 종류(class)별 빈도
ggplot(data=mpg, aes(x=class)) + geom_bar()


# 선 그래프
# 시계열 데이터를 표현할 때
economics
?economics
ggplot(data=economics, aes(x=date, y=unemploy)) +
  geom_line()

ggplot(data=economics, aes(x=date, y=psavert)) +
  geom_line()


# 상자그림, boxplot
ggplot(data = mpg, aes(x=drv, y=hwy)) + 
  geom_boxplot()

mpg %>% filter(class %in% c("compact", "subcompact", "suv")) -> class_mpg
head(class_mpg)

ggplot(data = class_mpg, aes(x = class, y = cty)) +
  geom_boxplot()


# geom_point() : 산점도
# geom_col() : 막대그래프 - 요약표
# geom_bar() : 막대그래프 - 원자료
# geom_line() : 선그래프(시계열 데이터 표현 시)
# geom_boxplot() : 상자 그림(데이터 분포, 이상치, 편향)






















