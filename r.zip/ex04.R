#조건에 맞는 데이터만 추출하기
library(dplyr)
exam <- read.csv("./data/csv_exam.csv")
head(exam)
dim(exam)

exam %>% filter(class == 1)
?filter
# %>% --> ctrl + shift + m

exam %>% filter(class == 2)
exam %>% filter(class != 2)
exam %>% filter(math > 50)
exam %>% filter(math > 50 & class == 1)
exam %>% filter(class == 2 & english >= 80)
exam %>% filter(math >= 90 | english >= 90)

#1,3,5 class 만 추출
exam %>% filter(class == 1 | class == 3 | class ==5)
exam %>% filter(class %in% c(1,3,5))

class1 <- exam %>% filter(class == 1)
class1

exam %>% filter(class == 1) -> class1
class1

mean(class1$math)

#---------------------------------------------#
#Q1 -- 배기량이 4이하인 자동차의 고속도로 연비
mpg <- as.data.frame(ggplot2::mpg)
head(mpg)
library(dplyr)
displ4 <- mpg %>% filter(displ <= 4)
displ5 <- mpg %>% filter(displ >= 5)

mean(displ4$hwy)
mean(displ5$hwy)

#Q2 -- toyota 더 높음
audi <- mpg %>% filter(manufacturer == 'audi')
toyota <- mpg %>% filter(manufacturer == 'toyota')

mean(audi$cty)
mean(toyota$cty)


#Q3 -- 22.50943
car3 <- mpg %>% filter(manufacturer=="chevrolet"
                       | manufacturer=="ford" 
                       | manufacturer=="honda"
                       )

car3 <- mpg %>% filter(manufacturer %in% c("chevrolet",
                                           "ford",
                                           "honda"))

mean(car3$hwy)


#필요한 컬럼만 추출
exam %>% select(math)
exam %>% select(english)
exam %>% select(math,english)
exam %>% select(-math)
exam %>% select(-math,-english)

#filter와 select 조합
exam %>% filter(class == 1) %>% select(english)

#select와 filter 사용의 순서는 데이터에 따라 다름
#select는 변수(열)를 추출
#filter는 행 조건을 줘서 추출


exam %>% select(id, math) %>% head(3)

mpg <- as.data.frame(ggplot2::mpg)
df <- mpg %>% select(class, cty)
head(df)

df_suv <- df %>% filter(class == 'suv')
df_compact <- df %>% filter(class == 'compact')

mean(df_suv$cty)
mean(df_compact$cty)


#정렬
exam %>% arrange(math)
exam %>% arrange(desc(math))

mpg %>% filter(manufacturer == 'audi') %>% arrange(desc(hwy)) %>% head(5) -> a 
a

#mutate()
exam %>% mutate(total = math + english + science) %>% head(3)
exam %>% mutate(total = math + english + science,
                mean = (math + english + science)/3) %>% head(3)

exam %>% mutate(total = math + english + science,
                mean = (math + english + science)/3,
                test = ifelse(science >= 60, "pass", "fail")) %>% 
          arrange(desc(total)) %>% 
          head(3)


mpg <- as.data.frame(ggplot2::mpg)
mpg_df <- mpg

mpg_df <- mpg_df %>% mutate(total = cty + hwy)
head(mpg_df)
mpg_df <- mpg_df %>% mutate(mean = total / 2)
head(mpg_df)

mpg_df %>% arrange(desc(mean)) %>% head(3) %>% select(class)

mpg %>% mutate(total = cty + hwy,
               mean = (cty + hwy) / 2) %>% 
                arrange(desc(mean)) %>% 
                select(class) %>%
                head(3)

# Q1. mpg 데이터 복사, 합산 연비 컬럼 추가
mpg
mpg_new <- mpg
mpg_new < - mpg_new %>% mutate(total = cty + hwy)
head(mpg_new)

# Q2. 합산 연비 컬럼을 2로 나눔
mpg_new <- mpg_new %>% mutate(mean = total /2)
head(mpg_new)

# Q3. 평균연비 상위 3개 출력
mpg_new %>% arrange(desc(mean)) %>% head(3)

# Q4. dplyr 하나의 문장
mpg %>% mutate(total = cty + hwy,
               mean = total / 2) %>% 
        arrange(desc(mean)) %>% 
        head(3)


# 집단별로 요약하기
exam %>% summarise(mean_math = mean(math))

exam %>% group_by(class) %>% summarise(mean_math = mean(math))

exam %>% group_by(class) %>% 
         summarise(mean_math = mean(math), #평균
                   sum_math = sum(math), #합계
                   median_math = median(math), #중앙값
                   min_math = min(math), #최솟값
                   max_math = max(math), #최댓값
                   sd_math = sd(math), #표준편차
                   n = n()) # 개 수

mpg %>% 
  group_by(manufacturer,drv) %>% 
  summarise(mean_cty = mean(cty)) %>% 
  arrange(desc(mean_cty)) %>% 
  head(5)

# 회사별로 suv 자동차의 도시 및 고속도로 통합 연비 평균을 구해
# 내림차순으로 정렬하고, 1위~5위까지 출력
mpg %>% group_by(manufacturer) %>% 
        filter(class == 'suv') %>% 
        mutate(total = cty + hwy)%>% 
        summarise(total_mean = mean(total)) %>% 
        arrange(desc(total_mean)) %>% 
        head(5)





