#단계구분도
#packages install
install.packages('mapproj')
install.packages('stringi')
install.packages('ggiraphExtra')

# 지도 차트
library(ggiraphExtra)
str(USArrests)
dim(USArrests)
head(USArrests)
library(tibble)
crime <- rownames_to_column(USArrests, var = "state")
crime$state <- tolower(crime$state)
str(crime)
install.packages("maps")
library(ggplot2)
states_map <- map_data("state")
str(states_map)
library(ggiraphExtra)
library(tibble)
ggChoropleth(data = crime,         #지도에 표현할 데이터
             aes(fill = Murder,    #색깔로 표현한 컬럼
                 map_id = state),  #지역 기준 컬럼
             map = states_map)     #지도 데이터


#한국 시도별 인구, 결핵 환자 수 지도 그래프
install.packages("stringi") #문자열 처리 라이브러리
install.packages("devtools")
devtools::install_github("cardiomoon/kormaps2014")
library(kormaps2014)
str(changeCode(korpop1))

#1. korpop1 : 2015년 센서스데이터(시도별)
#2. korpop2 : 2015년 센서스데이터(시구군별)
#3. korpop3 : 2015년 센서스데이터(읍면동별)

#1. kormap1 : 2014년 한국행정지도(시도별)
#2. kormap2 : 2014년 한국행정지도(시군구별)
#3. kormap3 : 2014년 한국행정지도(읍면동별)

library(dplyr)
korpop1 <- rename(korpop1, 
                  pop=총인구_명,
                  name=행정구역별_읍면동)
korpop1$name <- iconv(korpop1$name,"UTF-8","CP949")

str(changeCode(korpop1))
ggChoropleth(data = korpop1, 
             aes(fill = pop,        #색깔로 표현할 변수
                 map_id = code,     #지역 기준 변수
                 tooltip = name),   #지도 위에 표시할 지역명
              map = kormap1,        #지도 데이터
              interactive = T)      #인터랙티브

# 결핵 환자 수 단계 구분 지도
str(changeCode(tbc)) 
tbc$name <- iconv(tbc$name,"UTF-8","CP949")
ggChoropleth(data = tbc,           #지도에 표현할 데이터
             aes(fill = NewPts,    #색깔로 표현할 변수  (NewPts=Number of new patients)
                 map_id = code,    #지역 기준 변수
                 tooltip = name),  #지도 위에 표시할 지역명 
             map = kormap1,        #지도 데이터
             interactive = T)      #인터랙티브 : 마우스 움직임에 반응)
?ggChoropleth






